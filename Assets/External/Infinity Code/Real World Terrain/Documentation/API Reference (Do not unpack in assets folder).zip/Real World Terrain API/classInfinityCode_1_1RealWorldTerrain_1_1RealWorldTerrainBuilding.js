var classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding =
[
    [ "baseHeight", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#ab285009a534f33987640b0acb5e21990", null ],
    [ "baseVerticles", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#a5ede7d867bfebb97ce02391511e145fa", null ],
    [ "container", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#a7c0e68a1471a72fec9e63de22e9f8f5a", null ],
    [ "invertRoof", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#a58a7cdc91c6f5b495bfafba756bb1fbd", null ],
    [ "invertWall", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#a7f68453f84f1c67662bca1949b45e67c", null ],
    [ "roof", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#aed9d6a9a4b8b8b43263ab5240d4d9232", null ],
    [ "roofHeight", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#a4f154f33ebd074766e616a4bc5eccbb3", null ],
    [ "roofType", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#ac04603d8c096f1fe2a54e55fc4b93263", null ],
    [ "wall", "classInfinityCode_1_1RealWorldTerrain_1_1RealWorldTerrainBuilding.html#a7bcdc7afc3c9091c56ca470abdbddb87", null ]
];